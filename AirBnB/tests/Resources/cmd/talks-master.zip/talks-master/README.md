# cmd2 Talks and Presentations
This repository contains code examples, slides, and links to videos of various talks and 
presentations about the [cmd2](https://github.com/python-cmd2/cmd2) Python framework for 
quickly building feature-rich and user-friendly interactive command line applications.

