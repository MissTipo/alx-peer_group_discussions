# PyOhio 2019

## A Hands-on Guide to Building Interactive Command-Line Apps with cmd2
This directory contains material for a [talk](https://www.pyohio.org/2019/presentations/68) presented at the
[PyOhio 2019](https://www.pyohio.org/2019/) conference in Columbus, OH by Todd Leonhardt and Kevin Van Brunt.  [Video](https://www.youtube.com/watch?v=pebeWrTqIIw) of the presentation is avilable on YouTube.
